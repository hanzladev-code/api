<?php

namespace App\Http\Controllers\CRM\Authenticated;

use App\Http\Controllers\Controller;
use App\Models\Offers;
use App\Models\UsersOffers;
use Illuminate\Http\Request;

class OfferController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $offers = Offers::with(['user', 'network', 'domain'])->get();
        return response()->json($offers);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'name' => 'required|string',
                'network_id' => 'required|exists:networks,id',
                'domain_id' => 'required|exists:domains,id',
                'device_urls' => 'required|array',
                'age' => 'required|string',
                'click_rate' => 'required|string',
                'details' => 'nullable|string',
                'countries' => 'required|string',
                'status' => 'required|in:active,paused,draft',
                'port' => 'string',
                'allow_multiple_clicks' => 'boolean',
                'proxy_check' => 'boolean',
                'assigned_users' => 'nullable|string'
            ]);
            $user = $request->user();
            $validated['user_id'] = $user->id;

            $offer = Offers::create($validated);

            if ($request->has('assigned_users') && is_array($request->assigned_users)) {
                foreach ($request->assigned_users as $userId) {
                    $existingRecord = UsersOffers::where('user_id', $userId)->first();

                    if ($existingRecord) {
                        // Get existing offer IDs and append new one
                        $offerIds = array_filter(explode(',', $existingRecord->offer_ids));
                        if (!in_array($offer->id, $offerIds)) {
                            $offerIds[] = $offer->id;
                        }
                        $offerIdsString = implode(',', $offerIds);
                    } else {
                        // Create new record with just this offer ID
                        $offerIdsString = $offer->id;
                    }

                    UsersOffers::updateOrCreate(
                        ['user_id' => $userId],
                        ['offer_ids' => $offerIdsString]
                    );
                }
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Offer created successfully',
                'offer' => $offer
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error creating offer',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $offer = Offers::with(['user', 'network', 'domain'])->findOrFail($id);
        return response()->json($offer);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $offer = Offers::findOrFail($id);

            $validated = $request->validate([
                'name' => 'string',
                'network_id' => 'exists:networks,id',
                'domain_id' => 'exists:domains,id',
                'device_urls' => 'array',
                'age' => 'string',
                'click_rate' => 'string',
                'details' => 'nullable|string',
                'countries' => 'required|string',
                'status' => 'required|in:active,paused,draft',
                'port' => 'string',
                'allow_multiple_clicks' => 'boolean',
                'proxy_check' => 'boolean',
                'assigned_users' => 'nullable|array'
            ]);

            $offer->update($validated);

            if ($request->has('assigned_users') && is_array($request->assigned_users)) {
                foreach ($request->assigned_users as $userId) {
                    $existingRecord = UsersOffers::where('user_id', $userId)->first();

                    if ($existingRecord) {
                        // Get existing offer IDs and append new one
                        $offerIds = array_filter(explode(',', $existingRecord->offer_ids));
                        if (!in_array($offer->id, $offerIds)) {
                            $offerIds[] = $offer->id;
                        }
                        $offerIdsString = implode(',', $offerIds);
                    } else {
                        // Create new record with just this offer ID
                        $offerIdsString = $offer->id;
                    }

                    UsersOffers::updateOrCreate(
                        ['user_id' => $userId],
                        ['offer_ids' => $offerIdsString]
                    );
                }
            }
            return response()->json([
                'status' => 'success',
                'message' => 'Offer updated successfully',
                'offer' => $offer
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error updating offer',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $offer = Offers::findOrFail($id);
        try {
            $offer->delete();
            return response()->json([
                'status' => 'success',
                'message' => 'Offer deleted successfully',
            ], 204);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error deleting offer',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
